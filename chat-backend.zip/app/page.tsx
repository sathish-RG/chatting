"use client"

import  from "../server"

export default function SyntheticV0PageForDeployment() {
  return < />
}