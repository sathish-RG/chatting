import asyncHandler from "express-async-handler"
import Message from "../models/messageModel.js"
import User from "../models/userModel.js"
import Chat from "../models/chatModel.js"

export const allMessages = asyncHandler(async (req, res) => {
  try {
    const messages = await Message.find({ 
      chat: req.params.chatId,
      isDeleted: false 
    })
      .populate('sender', 'name profilePhoto email')
      .populate('chat');
    res.json(messages);
  } catch (error) {
    res.status(400);
    throw new Error(error.message);
  }
})

export const sendMessage = asyncHandler(async (req, res) => {
  const { content, chatId } = req.body

  if (!content || !chatId) {
    console.log("Invalid data passed into request")
    return res.sendStatus(400)
  }

  const newMessage = {
    sender: req.user._id,
    content: content,
    chat: chatId,
  }

  if (req.file) {
    newMessage.fileUrl = req.file.path
  }

  try {
    var message = await Message.create(newMessage)

    message = await message.populate("sender", "name profilePhoto")
    message = await message.populate("chat")
    message = await User.populate(message, {
      path: "chat.users",
      select: "name profilePhoto email",
    })

    await Chat.findByIdAndUpdate(req.body.chatId, { latestMessage: message })

    res.json(message)
  } catch (error) {
    res.status(400)
    throw new Error(error.message)
  }
})

export const deleteMessage = asyncHandler(async (req, res) => {
  const { messageId } = req.params;

  const message = await Message.findById(messageId);

  if (!message) {
    res.status(404);
    throw new Error('Message not found');
  }

  // Check if the user is the sender of the message
  if (message.sender.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('User not authorized to delete this message');
  }

  message.isDeleted = true;
  await message.save();

  res.json({ message: 'Message deleted successfully' });
});

export const editMessage = asyncHandler(async (req, res) => {
  const { messageId } = req.params;
  const { content } = req.body;

  const message = await Message.findById(messageId);

  if (!message) {
    res.status(404);
    throw new Error('Message not found');
  }

  // Check if the user is the sender of the message
  if (message.sender.toString() !== req.user._id.toString()) {
    res.status(403);
    throw new Error('User not authorized to edit this message');
  }

  message.content = content;
  const updatedMessage = await message.save();

  res.json(updatedMessage);
});

