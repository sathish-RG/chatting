import asyncHandler from "express-async-handler"
import User from "../models/userModel.js"

export const updateProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id)

  if (user) {
    user.name = req.body.name || user.name
    user.email = req.body.email || user.email
    if (req.body.password) {
      user.password = req.body.password
    }

    const updatedUser = await user.save()

    res.json({
      _id: updatedUser._id,
      name: updatedUser.name,
      email: updatedUser.email,
      profilePhoto: updatedUser.profilePhoto,
    })
  } else {
    res.status(404)
    throw new Error("User not found")
  }
})

export const uploadProfilePhoto = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user._id)

  if (user) {
    if (req.file) {
      user.profilePhoto = req.file.path
      const updatedUser = await user.save()
      res.json({
        _id: updatedUser._id,
        name: updatedUser.name,
        email: updatedUser.email,
        profilePhoto: updatedUser.profilePhoto,
      })
    } else {
      res.status(400)
      throw new Error("No file uploaded")
    }
  } else {
    res.status(404)
    throw new Error("User not found")
  }
})

