import express from "express"
import { protect } from "../middleware/authMiddleware.js"
import { updateProfile, uploadProfilePhoto } from "../controllers/userController.js"
import upload from "../middleware/uploadMiddleware.js"

const router = express.Router()

router.put("/profile", protect, updateProfile)
router.post("/upload-photo", protect, upload.single("photo"), uploadProfilePhoto)

export default router

